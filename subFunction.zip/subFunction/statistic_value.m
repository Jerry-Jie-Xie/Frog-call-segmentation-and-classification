% Calcualte statistical values of frame/window based features (9)
function res = statistic_value(y)

% res = [max(y), min(y), range(y), mean(y), std(y),...
%     median(y), var(y), skewness(y), kurtosis(y)];
res = [mean(y), var(y), skewness(y), kurtosis(y)];
% res = [mean(y), var(y)];

end
%[EOF]