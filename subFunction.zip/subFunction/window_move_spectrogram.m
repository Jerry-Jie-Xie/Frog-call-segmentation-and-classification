% Apply a sliding window to x and segment it into windowed signal
function [res] = window_move_spectrogram(signal, win_size, win_over)
%=============================================================%
fs = 44100;
%=============================================================%
[row_value, col_value] = size(signal);
%=============================================================%
if row_value < col_value
    signal = signal';
end
%=============================================================%
len_signal = length(signal);
num_signal = floor((len_signal - win_size*win_over) / (win_size*(1-win_over)));
win_signal = cell(1, num_signal);
for idxSignal = 1:num_signal
    start_signal = int64((idxSignal - 1)*win_size*(1-win_over)+1);
    stop_signal = start_signal+win_size-1;
    temp_sig = signal(start_signal:stop_signal);
    
    [cepstra,aspectrum,pspectrum] = melfcc(temp_sig, fs, floor(length(temp_sig)/20), floor(length(temp_sig)/40), ...
        'minfreq', 100, 'maxfreq', 8000, 'nbands', 128);
    
    win_signal{idxSignal} = temp_sig;
end
%=============================================================%
res = cell2mat(win_signal);
%=============================================================%
end
%[EOF]
