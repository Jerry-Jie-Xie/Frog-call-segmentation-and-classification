function res= vector_to_label(optimal_segment)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

stop_loc = 0; start_loc = 0;
for k = 1:length(optimal_segment)-1
    if optimal_segment(k) == 0 && optimal_segment(k+1) == 1
        start_loc = [start_loc, k+1];
    %elseif (optimal_segment(k) == 1 && optimal_segment(k+1) == 0) || (optimal_segment(k+1) == 1 && (k+1 == length(optimal_segment)))
    elseif optimal_segment(k) == 1 && optimal_segment(k+1) == 0
        stop_loc = [stop_loc, k];
    end
end

start_loc(1) = []; stop_loc(1) = [];

res = [start_loc; stop_loc]';

end
%[EOF]
