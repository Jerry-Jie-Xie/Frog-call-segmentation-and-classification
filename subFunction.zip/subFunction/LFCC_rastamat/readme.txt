code usage: 
% feat = make_feat_mfcc_rastamat( sig, fs, 1 ) %'mel'
% feat = make_feat_mfcc_rastamat( sig, fs, 2 ) % 'linear' 


Feat : 19+delta, 38 dimension

Please look into make_feat_mfcc_rastamat.m for details of implementation. 

Thanks to Dr. D. Ellis allowing us use his package and put the revised version here. 

Please contact Xinhui zhou at (zxinhui@umd.edu) if you have any question. 




