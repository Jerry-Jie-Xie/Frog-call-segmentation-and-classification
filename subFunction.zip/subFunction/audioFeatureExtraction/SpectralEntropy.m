function En = SpectralEntropy(signal, windowLength, windowStep, fftLength, numOfBins)
if length(signal) < windowLength
    signal = [signal; zeros( windowLength - length(signal),1)];
end
signal = signal / max(abs(signal));
curPos = 1;
L = length(signal);
numOfFrames = floor((L-windowLength)/windowStep) + 1;
H = hamming(windowLength);
En = zeros(numOfFrames,1);
h_step = fftLength / numOfBins;
% fs = 100;
for i=1:numOfFrames
    window = (H.*signal(curPos:curPos+windowLength-1));
 
    fftTemp = abs(fft(window,2*fftLength));
    fftTemp = fftTemp(1:fftLength);
    S = sum(fftTemp+1e-12);    
    x = zeros(numOfBins, 1);
    for j=1:numOfBins
        x(j) = sum(fftTemp((j-1)*h_step + 1: j*h_step)) / S;
    end
    
    x = fftTemp./S;
    En(i) = -sum(x.*log2(x));
    
    % N = length(window);    
    % Y=fft(window);
    % % Compute the Power Spectrum
    % sqrtPyy = ((sqrt(abs(Y).*abs(Y))*2)/N);
    % %sqrtPyy = abs(Y).^2;
    % sqrtPyy = sqrtPyy(1:N/2);     
    % %Normalization
    % d=sqrtPyy(:);
    % d=d/sum(d+1e-12);    
    % %Entropy Calculation
    % logd = log2(d + 1e-12);
    % En(i) = -sum(d.*logd)/log2(length(d));
    
    curPos = curPos + windowStep;
end
%[EOF]

