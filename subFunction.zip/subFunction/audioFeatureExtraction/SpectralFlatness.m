function [spf] = SpectralFlatness(signal,windowLength, step)

if length(signal) < windowLength
    signal = [signal; zeros( windowLength - length(signal),1)];
end
signal = signal / max(abs(signal));
% [row, col]= size(signal);
% if row < col
%     signal = signal';
% end
curPos = 1;
L = length(signal);
numOfFrames = floor((L-windowLength)/step) + 1;
H = hamming(windowLength);
spf = zeros(numOfFrames,1);
for i=1:numOfFrames
    window = H.*(signal(curPos:curPos+windowLength-1));
    pxx = periodogram(window);
    num=geomean(pxx);
    den=mean(pxx);
    spf(i)=num/den ;
    curPos = curPos + step;
end

end
%[EOF]
