% APPLY a sliding window to x and segment it into windowed signal, and
% calculate multiple temporal and spectral features
function [res] = window_based_feat(signal, win_size, win_over, fs)

[row_value, col_value] = size(signal);

if row_value < col_value
    signal = signal';
end

len_signal = length(signal);
num_signal = floor((len_signal - win_size*win_over) / (win_size*(1-win_over)));
win_feat = cell(num_signal, 1);

temp_win_len = floor(win_size/20);
temp_win_step = floor(win_size/40);

add_zero_coeff = 1; do_filter = 0;
params = MFCCs_parameter_setting(300, fs/2, temp_win_len, temp_win_step, 40, add_zero_coeff, do_filter);

for idxSignal = 1:num_signal
    
    disp([num2str(num_signal), ':', num2str(idxSignal)])
    
    start_signal = int64((idxSignal - 1)*win_size*(1-win_over)+1);
    stop_signal = start_signal+win_size-1;
    y = signal(start_signal:stop_signal);
        
    % Calcualte frequency feature
    freq_feat = extract_spectral_feature(y, fs, temp_win_len, temp_win_step, params);
    
    % Calculate temporal feature
    temp_feat = extract_temporal_feature(y, temp_win_len, temp_win_step);
        
    win_feat{idxSignal} = [temp_feat, freq_feat'];
    
end

res = remove_Inf_nan(cell2mat(win_feat));

end
%[EOF]
