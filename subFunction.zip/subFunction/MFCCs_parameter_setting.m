% set specified frequency band for calculating MFCCs
function params = MFCCs_parameter_setting(f1, f2, wintime, hoptime, nbands, C0, filter)

params.version = 2 ;  % using the revised mfcc fucntion
params.numcep = 20 ;
params.dither = 1 ;
params.prefilter = filter ; % 1: do the filter; 0: no filter
params.minfreq = f1 ; %
params.maxfreq = f2 ; % change 3400Hz to 5000Hz
params.wintime = wintime ; % 20 ms
params.hoptime = hoptime;
params.nbands = nbands ; % 32 is the number that the linconln lab system used. change to 40
params.modelorder = 0 ; %assuming mfcc , not plp
params.C0 = C0 ; % 0: not add 0th order coefficient
params.delta = 2 ;
params.delta_half_win = 5 ;   % 5 was obtaiend by using sre08
% decimated subset and run difrent window size
% params.delta_half_win = 2 ; % default one in LL
params.compression = 'log' ;
params.sig_norm    = 1 ;
params.usecmp = 0 ;
params.invert_melscale = 0 ;
params.dorasta = 0 ;

end
%[EOF]