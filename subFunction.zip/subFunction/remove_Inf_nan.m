% Remove infinite and NAN value
function [res] = remove_Inf_nan(data)
data(isnan(data)) = 0;
data(~isfinite(data)) = 0;
res = data;
end
%[EOF]