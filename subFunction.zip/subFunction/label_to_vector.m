function [manual_label_data] = label_to_vector(manual_label_info, y)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

manual_label_data = zeros(1, length(y));
[row, ~] = size(manual_label_info);
for r = 1: row
    start_loc = manual_label_info(r, 1);
    stop_loc = manual_label_info(r, 2);
    manual_label_data(start_loc: stop_loc) = 1;
end

end
%[EOF]

