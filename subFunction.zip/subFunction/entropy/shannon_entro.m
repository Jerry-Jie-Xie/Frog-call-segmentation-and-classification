function y=shannon_entro(x)

x = x / norm(x, 1); % using the 1-norm

[M,N]=size(x);
if M < N
    x = x';
    y=zeros(1,M);
else
    y=zeros(1,N);
end
for l=1:min(M,N)
    select_x = x(:,l);
    select_x = select_x(select_x>0);
    sum1=sum(select_x.*log2(select_x));
    sum1=-1*sum1;
    y(1,l)=sum1;
end
%[EOF]
