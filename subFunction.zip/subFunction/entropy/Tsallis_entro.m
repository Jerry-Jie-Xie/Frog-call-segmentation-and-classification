function y=Tsallis_entro(x,q)

[M,N]=size(x);
if M < N
    x = x';
    y=zeros(1,M);
else
    y=zeros(1,N);
end
for l=1:min(M,N)
    sum1=sum(x(:,l)-(x(:,l)).^q);
    sum2=sum1/(q-1);
    y(1,l)=sum2;
end
%[EOF]