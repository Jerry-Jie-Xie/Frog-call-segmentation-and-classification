% Calculate temporal features of windowed signal
function res = extract_temporal_feature(y, temp_win_len, temp_win_step)

energy_y = statistic_value(ShortTimeEnergy(y, temp_win_len, temp_win_step));
% entropy_y = mean(ShortTimeEntropy(y, floor(length(y)/20), floor(length(y)/40), 'shannon'));
zero_crosss_rate_y = statistic_value(zcr(y, temp_win_len, temp_win_step));
% CF_y = mean(CrestFactor(y, floor(length(y)/20), floor(length(y)/40)));
res = [ energy_y, zero_crosss_rate_y];

end
%[EOF]
