% Calcualte spectral feature for time series (Frame based)
function res = extract_spectral_feature(y, fs, temp_win_len, temp_win_step, params)

% temp_win_len = floor(length(y)/20);
% temp_win_step = floor(length(y)/40);
% tic;
feats_MFCC = make_feat_mfcc_rastamat( y, fs, 1, params ); % MFCC
feats_LFCC = make_feat_mfcc_rastamat( y, fs, 2, params ); % LFCC

mean_MFCC = mean(feats_MFCC(1:20,:),2); mean_LFCC = mean(feats_LFCC(1:20,:),2);

centroid = statistic_value(SpectralCentroid(y, temp_win_len, temp_win_step, fs));
flux = statistic_value(SpectralFlux(y, temp_win_len, temp_win_step));
rolloff = statistic_value(SpectralRollOff(y, temp_win_len, temp_win_step, 0.80, fs));
En = statistic_value(SpectralEntropy(y, temp_win_len, temp_win_step, temp_win_len, temp_win_len));
flat = statistic_value(SpectralFlatness(y, temp_win_len, temp_win_step));

% toc
% tic;
% my_window = hamming(temp_win_len);
% [flatness,arithmeticMean,geometricMean] = spectralFlatness(y, fs, 'Window', my_window, 'OverlapLength',temp_win_step)
% flatness = statistic_value(flatness);
% toc

res = [mean_MFCC; mean_LFCC; centroid'; flux'; rolloff'; En'; flat'];

end
%[EOF]
